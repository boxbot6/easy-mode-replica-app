package com.example.easymodereplica

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.text.DynamicLayout
import android.text.Layout
import android.text.TextPaint
import android.widget.RemoteViews
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import java.util.Calendar


open class Widget1Activity : AppWidgetProvider() {
    private var clockTouchActive = false
    private var locationTouchActive = false
    private var weatherTouchActive = false
    private var dateTouchActive = false
    private var updateTouchActive = false
    private var clockIntentText: String? = null
    private var locationIntentText: String? = null
    private var weatherIntentText: String? = null
    private var dateIntentText: String? = null


    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val thisWidget = ComponentName(context, Widget1Activity::class.java)
        val allWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget)
        for (widgetId in allWidgetIds) {
            val remoteViews = RemoteViews(context.packageName, R.layout.activity_widget1)

            // load values
            val sharedSettings = context.getSharedPreferences("Shared_Settings", 0)
            val editor = sharedSettings.edit()
            locationTouchActive = sharedSettings.getBoolean("locationTouchActive", true)
            val locationJSON = sharedSettings.getString("locationJSON", "Set Location")
            val temperature = sharedSettings.getString("temperature", "     °C")
            val description = sharedSettings.getString("description", "N/A")
//            val enterCityButtonPressedTag = sharedSettings.getBoolean("enterCityButtonPressedTag", false)
//            val allowLocationButtonPressedTag = sharedSettings.getBoolean("allowLocationButtonPressedTag", false)
            val nightTag = sharedSettings.getBoolean("nightTag", false)

            // sets the location button touch active if location is empty
            if (locationJSON === "Set Location" && locationTouchActive) {
                editor.putBoolean("locationTouchActive", true)
            }
            editor.apply()


            // convert openweathermap descriptions to easy_weather_icons_font
            // (feel free to use this font conversion list in your own app.)
            var icon = "\uE900" // creates icon string and sets default icon to: (N/A)

            if (description == "") { icon = "\uE900" } // sets empty icon to: (N/A)
            if (description == null) { icon = "\uE900" } // sets null icon to: (N/A) keep this in case null is reset
            if (description == "clear sky") { icon = "\uE96D" } // CLEARday
            if (description == "clear sky" && nightTag) { icon = "\uE96E" } // CLEARnight
            if (description == "few clouds") { icon = "\uE967" } // PARTLY_CLOUDYday (few clouds: 11-25%)
            if (description == "few clouds" && nightTag) { icon = "\uE968" } // PARTLY_CLOUDYnight (few clouds: 11-25%)
            if (description == "scattered clouds") { icon = "\uE9D3" } // CLOUD2day (scattered clouds: 25-50%)
            if (description == "scattered clouds" && nightTag) { icon = "\uE9D4" } // CLOUD2night (scattered clouds: 25-50%)
            if (description == "broken clouds") { icon = "\uE9DF" } // CLOUDY2day (broken clouds: 51-84%)
            if (description == "broken clouds" && nightTag) { icon = "\uE9E0" } // CLOUDY2night (broken clouds: 51-84%)
            if (description == "overcast clouds") { icon = "\uE961" } // MOSTLY_CLOUDYday (overcast clouds: 85-100%)
            if (description == "overcast clouds" && nightTag) { icon = "\uE962" } // MOSTLY_CLOUDYnight (overcast clouds: 85-100%)
            if (description == "shower rain") { icon = "\uE928" } // SHOWERSday
            if (description == "shower rain" && nightTag) { icon = "\uE929" } // SHOWERSnight
            if (description == "rain") { icon = "\uE92E" } // RAINday
            if (description == "rain" && nightTag) { icon = "\uE932" } // RAINnight
            if (description == "thunderstorm") { icon = "\uE910" } // THUNDERSTORMSday
            if (description == "thunderstorm" && nightTag) { icon = "\uE911" } // THUNDERSTORMSnight
            if (description == "snow") { icon = "\uE940" } // SNOWday
            if (description == "snow" && nightTag) { icon = "\uE941" } // SNOWnight
            if (description == "mist") { icon = "\uEA42" } // mistday
            if (description == "mist" && nightTag) { icon = "\uEA43" } // mistnight
            if (description == "thunderstorm with light rain") {icon = "\uEA60" } // thunderstorm_with_light_rainday
            if (description == "thunderstorm with light rain" && nightTag) { icon = "\uEA61" } // thunderstorm_with_light_rainnight
            if (description == "thunderstorm with rain") { icon = "\uEA63" } // thunderstorm_with_rainday
            if (description == "thunderstorm with rain" && nightTag) { icon = "\uEA64" } // thunderstorm_with_rainnight
            if (description == "thunderstorm with heavy rain") { icon = "\uEA66" } // thunderstorm_with_heavy_rainday
            if (description == "thunderstorm with heavy rain" && nightTag) { icon = "\uEA67" } // thunderstorm_with_heavy_rainnight
            if (description == "light thunderstorm") { icon = "\uE910" } // THUNDERSTORMSday
            if (description == "light thunderstorm" && nightTag) { icon = "\uE911" } // THUNDERSTORMSnight
            if (description == "heavy thunderstorm") { icon = "\uE90D" } // SEVERE_THUNDERSTORMSday
            if (description == "heavy thunderstorm" && nightTag) { icon = "\uE90E" } // SEVERE_THUNDERSTORMSnight
            if (description == "ragged thunderstorm") { icon = "\uEA69" } // ragged_thunderstormday
            if (description == "ragged thunderstorm" && nightTag) { icon = "\uEA6A" } // ragged_thunderstormnight
            if (description == "thunderstorm with light drizzle") { icon = "\uE982" } // THUNDERSHOWERSday
            if (description == "thunderstorm with light drizzle" && nightTag) { icon = "\uE983" } // THUNDERSHOWERSnight
            if (description == "thunderstorm with drizzle") { icon = "\uEA6C" } // thunderstorm_with_drizzleday
            if (description == "thunderstorm with drizzle" && nightTag) { icon = "\uEA6D" } // thunderstorm_with_drizzlenight
            if (description == "thunderstorm with heavy drizzle") { icon = "\uE982" } // THUNDERSHOWERSday
            if (description == "thunderstorm with heavy drizzle" && nightTag) { icon = "\uE983" } // THUNDERSHOWERSnight
            if (description == "light intensity drizzle") { icon = "\uE922" } // DRIZZLEday
            if (description == "light intensity drizzle" && nightTag) { icon = "\uE923" } // DRIZZLEnight
            if (description == "drizzle") { icon = "\uE922" } // DRIZZLEday
            if (description == "drizzle" && nightTag) { icon = "\uE923" } // DRIZZLEnight
            if (description == "heavy intensity drizzle") { icon = "\uE922" } // DRIZZLEday
            if (description == "heavy intensity drizzle" && nightTag) { icon = "\uE923" } // DRIZZLEnight
            if (description == "light intensity drizzle rain") { icon = "\uE922" } // DRIZZLEday
            if (description == "light intensity drizzle rain" && nightTag) { icon = "\uEA70" } // DRIZZLEnight
            if (description == "drizzle rain") { icon = "\uEA6F" } // drizzle_rainday
            if (description == "drizzle rain" && nightTag) { icon = "\uEA01" } // drizzle_rainnight
            if (description == "heavy intensity drizzle rain") { icon = "\uEA00" } // RAINYday
            if (description == "heavy intensity drizzle rain" && nightTag) { icon = "\uEA01" } // RAINYnight
            if (description == "shower rain and drizzle") { icon = "\uE928" } // SHOWERSday
            if (description == "shower rain and drizzle" && nightTag) { icon = "\uE929" } // SHOWERSnight
            if (description == "heavy shower rain and drizzle") { icon = "\uE931" } // HEAVY_SHOWERSday
            if (description == "heavy shower rain and drizzle" && nightTag) { icon = "\uE932" } // HEAVY_SHOWERSnight
            if (description == "shower drizzle") { icon = "\uE928" } // SHOWERSday
            if (description == "shower drizzle" && nightTag) { icon = "\uE929" } // SHOWERSnight
            if (description == "light rain") { icon = "\uEA00" } // RAINYday
            if (description == "light rain" && nightTag) { icon = "\uEA01" } // RAINYnight
            if (description == "moderate rain") { icon = "\uE92E" } // RAINday
            if (description == "moderate rain" && nightTag) { icon = "\uE932" } // RAINnight
            if (description == "heavy intensity rain") { icon = "\uE92E" } // RAINday
            if (description == "heavy intensity rain" && nightTag) { icon = "\uE932" } // RAINnight
            if (description == "very heavy rain") { icon = "\uEA03" } // RAINY2day
            if (description == "very heavy rain" && nightTag) { icon = "\uEA04" } // RAINY2night
            if (description == "extreme rain") { icon = "\uEA03" } // RAINY2day
            if (description == "extreme rain" && nightTag) { icon = "\uEA04" } // RAINY2night
            if (description == "freezing rain") { icon = "\uE925" } // FREEZING_RAINday
            if (description == "freezing rain" && nightTag) { icon = "\uE926" } // FREEZING_RAINnight
            if (description == "light intensity shower rain") { icon = "\uE928" } // SHOWERSday
            if (description == "light intensity shower rain" && nightTag) { icon = "\uE929" } // SHOWERSnight
            if (description == "heavy intensity shower rain") { icon = "\uE931" } // HEAVY_SHOWERSday
            if (description == "heavy intensity shower rain" && nightTag) { icon = "\uE932" } // HEAVY_SHOWERSnight
            if (description == "ragged shower rain") { icon = "\uE928"  } // SHOWERSday
            if (description == "ragged shower rain" && nightTag) { icon = "\uE929" } // SHOWERSnight
            if (description == "light snow") { icon = "\uE937" } // LIGHT_SNOW_SHOWERSday
            if (description == "light snow" && nightTag) { icon = "\uE938" } // LIGHT_SNOW_SHOWERSnight
            if (description == "heavy snow") { icon = "\uE97C" } // HEAVY_SNOWday
            if (description == "heavy snow" && nightTag) { icon = "\uE97D" } // HEAVY_SNOWnight
            if (description == "sleet") { icon = "\uE946" } // SLEETday
            if (description == "sleet" && nightTag) { icon = "\uE947" } // SLEETnight
            if (description == "light shower sleet") { icon = "\uE919" } // MIXED_RAIN_SLEETday
            if (description == "light shower sleet" && nightTag) { icon = "\uE91A" } // MIXED_RAIN_SLEETnight
            if (description == "shower sleet") { icon = "\uE919" } // MIXED_RAIN_SLEETday
            if (description == "shower sleet" && nightTag) { icon = "\uE91A" } // MIXED_RAIN_SLEETnight
            if (description == "light rain and snow") { icon = "\uE916" } // MIXED_RAIN_SNOWday
            if (description == "light rain and snow" && nightTag) { icon = "\uE917" } // MIXED_RAIN_SNOWnight
            if (description == "rain and snow") { icon = "\uE916" } // MIXED_RAIN_SNOWday
            if (description == "rain and snow" && nightTag) { icon = "\uE917" } // MIXED_RAIN_SNOWnight
            if (description == "light shower snow") { icon = "\uE97F" } // SCATTERED_SNOW_SHOWERSday
            if (description == "light shower snow" && nightTag) { icon = "\uE980" } // SCATTERED_SNOW_SHOWERSnight
            if (description == "shower snow") { icon = "\uE988" } // SNOW_SHOWERSday
            if (description == "shower snow" && nightTag) { icon = "\uE989" } // SNOW_SHOWERSnight
            if (description == "heavy shower snow") { icon = "\uE97C" } // HEAVY_SNOWday
            if (description == "heavy shower snow" && nightTag) { icon = "\uE97D" } // HEAVY_SNOWnight
            if (description == "smoke") { icon = "\uEA45" } // smokeday
            if (description == "smoke" && nightTag) { icon = "\uEA46" } // smokenight
            if (description == "haze") { icon = "\uE952" } // HAZEday
            if (description == "haze" && nightTag) { icon = "\uE953" } // HAZEnight
            if (description == "sand/ dust whirls") { icon = "\uEA4B" } // sand/_dust_whirlsday
            if (description == "sand/ dust whirls" && nightTag) { icon = "\uEA4C" } // sand/_dust_whirlsnight
            if (description == "fog") { icon = "\uE94F" } // FOGday
            if (description == "fog" && nightTag) { icon = "\uE950" } // FOGnight
            if (description == "sand") { icon = "\uEA51" } // sandday
            if (description == "sand" && nightTag) { icon = "\uEA52" } // sandnight
            if (description == "dust") { icon = "\uEA51" } // DUSTday
            if (description == "dust" && nightTag) { icon = "\uE94A" } // DUSTnight
            if (description == "volcanic ash") { icon = "\uEA57" } // volcanic_ashday
            if (description == "volcanic ash" && nightTag) { icon = "\uEA58" } // volcanic_ashnight
            if (description == "squalls") { icon = "\uEA5A" } // squallsday
            if (description == "squalls" && nightTag) { icon = "\uEA5B" } // squallsnight
            if (description == "tornado") { icon = "\uE904" } // TORNADOday
            if (description == "tornado" && nightTag) { icon = "\uE905" } // TORNADOnight



// bitmap is used here because widgets produced by older android versions cannot use fonts from the assets folder!
            val bitmap = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            val textPaint = TextPaint()
            textPaint.setTypeface(ResourcesCompat.getFont(context, R.font.easy_weather_icons_font))
            textPaint.color = ContextCompat.getColor(context, R.color.weather_icons)
            textPaint.isAntiAlias = true
            textPaint.textSize = 188f

            val textLayout: DynamicLayout = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    DynamicLayout.Builder.obtain(icon, textPaint, canvas.width)
                        .setAlignment(Layout.Alignment.ALIGN_CENTER)
                        .setLineSpacing(0f, 1f)
                        .setIncludePad(false)
                        .build()
                } else {
                @Suppress("DEPRECATION")
                DynamicLayout(
                    icon,
                    textPaint,
                    canvas.width,
                    Layout.Alignment.ALIGN_CENTER,
                    1f,
                    0f,
                    false
                )
            }

                val textX = 0
                val textY = 0
                canvas.translate(textX.toFloat(), textY.toFloat())

            textLayout.draw(canvas)


            remoteViews.setImageViewBitmap(R.id.displayWeatherIconBitmap, bitmap)
            remoteViews.setTextViewText(R.id.btnLocation, locationJSON) // locationForWidget
            remoteViews.setTextViewText(R.id.displayTemperature, temperature)
            remoteViews.setOnClickPendingIntent(R.id.btnClock, getPendingSelfIntent(context, strClock))
            remoteViews.setOnClickPendingIntent(R.id.btnLocation, getPendingSelfIntent(context, strLocation))
            remoteViews.setOnClickPendingIntent(R.id.btnWeather, getPendingSelfIntent(context, strWeather))
            remoteViews.setOnClickPendingIntent(R.id.btnDate, getPendingSelfIntent(context, strDate))
            remoteViews.setOnClickPendingIntent(R.id.btnUpdate, getPendingSelfIntent(context, strButtonUpdate)) //strDate)) // strButtonUpdate))

            appWidgetManager.updateAppWidget(widgetId, remoteViews)

//            if (enterCityButtonPressedTag) {
//                Toast.makeText(context, "User-Set City Updated", Toast.LENGTH_SHORT).show();
//            } else if (allowLocationButtonPressedTag) {
//                Toast.makeText(context, "GPS-Set City Updated", Toast.LENGTH_SHORT).show();
//            }
        }
    }

    private fun getPendingSelfIntent(context: Context?, action: String?): PendingIntent {
        val intent = Intent(context, javaClass)
        intent.setAction(action)
        return PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_IMMUTABLE)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)

        //  load values
        val sharedSettings = context.getSharedPreferences("Shared_Settings", 0)
        val editor = sharedSettings.edit()
        clockTouchActive = sharedSettings.getBoolean("clockTouchActive", clockTouchActive)
        locationTouchActive = sharedSettings.getBoolean("locationTouchActive", locationTouchActive)
        weatherTouchActive = sharedSettings.getBoolean("weatherTouchActive", weatherTouchActive)
        dateTouchActive = sharedSettings.getBoolean("dateTouchActive", dateTouchActive)
        updateTouchActive = sharedSettings.getBoolean("updateTouchActive", updateTouchActive) // removed and set to permanently on
        clockIntentText = sharedSettings.getString("clockIntentText", locationIntentText)
            val splitClockIntentText = clockIntentText!!.split(", ".toRegex()).dropLastWhile { it.isEmpty() }
                .toTypedArray() // split string at ", "
            val clockIntentPartA = splitClockIntentText[0]
            val clockIntentPartB = splitClockIntentText[1]
        locationIntentText = sharedSettings.getString("locationIntentText", locationIntentText)
        weatherIntentText = sharedSettings.getString("weatherIntentText", weatherIntentText)
        dateIntentText = sharedSettings.getString("dateIntentText", dateIntentText)

        if (strClock == intent.action && clockTouchActive) {
            try {
                val clockIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(ComponentName(clockIntentPartA, clockIntentPartB))
                clockIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(clockIntent)
            } catch (e: Exception) {
                // alt code that opens clock using show alarms when intent does not work
                val clockIntent = Intent(AlarmClock.ACTION_SHOW_ALARMS)
                clockIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(clockIntent)
            }
        } else if (strLocation == intent.action && locationTouchActive) {
            try {
                val lc = locationIntentText?.let { Class.forName(it) }
                val locationIntent = Intent(context, lc)
                locationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                editor.putBoolean("mainLayoutIsOpenTag", true) // tag makes app open by default on main layout page to set location
                editor.putBoolean("settingsLayoutIsOpenTag", false)
                editor.apply()
                context.startActivity(locationIntent)
                Toast.makeText(context.applicationContext, "Set Location Here", Toast.LENGTH_LONG).show()
            } catch (ignored: ClassNotFoundException) {
            }
        } else if (strWeather == intent.action && weatherTouchActive) {
            val weatherIntent = Intent(Intent.ACTION_VIEW)
            weatherIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            weatherIntent.setData(Uri.parse(weatherIntentText))
            context.startActivity(weatherIntent)
        } else if (strDate == intent.action && dateTouchActive) {
            val dateIntent = Intent(Intent.ACTION_VIEW)
            dateIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            dateIntent.setData(Uri.parse(dateIntentText))
            context.startActivity(dateIntent)
        } else if (strButtonUpdate == intent.action) { // && updateTouchActive) // removed and set to permanently on
//            val updateIntent = Intent(context, GetWeatherActivity2::class.java)
//            context.startActivity(updateIntent)
//            updateWidgetButton(context)

            Toast.makeText(context, "Weather Update Pressed", Toast.LENGTH_SHORT).show()
//        } else if (strAutoUpdate == intent.action && updateTouchActive) {
//            val updateIntent = Intent(context, GetWeatherActivity::class.java)
//            context.startActivity(updateIntent)
//            updateWidgetButton(context)
//            Toast.makeText(context, "Scheduled Weather Update", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateWidgetButton(context: Context) {
        //  this onUpdate works within the widget after pressing the update button
        val appWidgetManager = AppWidgetManager.getInstance(context)
        val thisWidget = ComponentName(context, Widget1Activity::class.java)
        val appWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget)
        onUpdate(context, appWidgetManager, appWidgetIds)
    }

    // Enter relevant functionality for when the first widget is created
    override fun onEnabled(context: Context) {
        // start alarm
        val appWidgetAlarm = AppWidgetAlarm(context.applicationContext)
        appWidgetAlarm.startAlarm()
    }

    // Enter relevant functionality for when the last widget is disabled
    override fun onDisabled(context: Context) {
        // stop alarm only if all widgets have been disabled
        val appWidgetManager = AppWidgetManager.getInstance(context)
        val thisAppWidgetComponentName = ComponentName(context.packageName, javaClass.name)
        val appWidgetIds = appWidgetManager.getAppWidgetIds(thisAppWidgetComponentName)
        if (appWidgetIds.isEmpty()) {
            // stop alarm
            val appWidgetAlarm = AppWidgetAlarm(context.applicationContext)
            appWidgetAlarm.stopAlarm()
        }
    }

    class AppWidgetAlarm(
    // (min time between updates is 1 minute 1000 * 60 * 0)
        private val mContext: Context,
    ) {
        private val alarmID = 0
        private val intervalMillis = 1000 * 60 * 15 // alarm interval (1000 per second);
        fun startAlarm() {
            val calendar = Calendar.getInstance()
            calendar.add(Calendar.MILLISECOND, intervalMillis)
            val alarmIntent = Intent(mContext, Widget1Activity::class.java)
            alarmIntent.setAction(strAutoUpdate)
            val pendingAlarmIntent = PendingIntent.getBroadcast(
                mContext,
                alarmID,
                alarmIntent,
                PendingIntent.FLAG_CANCEL_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val alarmManager = mContext.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            // RTC does not wake the device up
            alarmManager.setRepeating(
                AlarmManager.RTC,
                calendar.timeInMillis,
                intervalMillis.toLong(),
                pendingAlarmIntent
            )
        }

        fun stopAlarm() {
            val alarmIntent = Intent(mContext, Widget1Activity::class.java)
            alarmIntent.setAction(strAutoUpdate)
            val pendingAlarmIntent = PendingIntent.getBroadcast(
                mContext,
                alarmID,
                alarmIntent,
                PendingIntent.FLAG_CANCEL_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val alarmManager = mContext.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmManager.cancel(pendingAlarmIntent)
        }
    }

    companion object {
        private const val strClock = "Open Clock"
        private const val strLocation = "Open Location"
        private const val strWeather = "Open Weather"
        private const val strDate = "Open Date"
        private const val strButtonUpdate = "Open Update"
        private const val strAutoUpdate = "Auto Update"

        fun updateAppWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {

            // Construct the RemoteViews object
            val views = RemoteViews(context.packageName, R.layout.activity_widget1)

            // Instruct the widget manager to update the widget
            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }

}