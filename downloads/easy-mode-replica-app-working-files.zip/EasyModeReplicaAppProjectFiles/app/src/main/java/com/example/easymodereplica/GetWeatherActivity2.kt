package com.example.easymodereplica

import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.CalendarContract
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.Executors


class GetWeatherActivity2 : AppCompatActivity() {
    private val myExecutor = Executors.newSingleThreadExecutor()
    private val myHandler = Handler(Looper.getMainLooper())

    // tags
    private var firstRunTag = true
    private var mainLayoutIsOpenTag = false
    private var settingsLayoutIsOpenTag = false
    private var moreAppsIsOpenTag = false
    private var gpsPermissionIsGivenTag = false
    private var locationPermissionIsGivenTag = false
    private var enterCityButtonPressedTag = false
    private var allowLocationButtonPressedTag = false
    private var nightTag = false

    // strings
    private var clockIntentText = "com.sec.android.app.clockpackage, com.sec.android.app.clockpackage.ClockPackage"
    private var locationIntentText = "com.example.easymodereplica.MainActivity"
    private var weatherIntentText = "https://www.bbc.co.uk/weather/4076598"
    private var dateUri = CalendarContract.CONTENT_URI.buildUpon().appendPath("time").build()
    private var dateIntentText = dateUri.toString() // created this string from above uri because it contains special character (")
    private var apiKey: String? = "73cbebdd0322acd49bda6ede059b2b18"
    private var logsButtonIntentText = "com.example.easymodereplica.LogsActivity"
    private var moreAppsButtonIntentText = "com.example.easymodereplica.MoreAppsActivity"
    private var homeButtonIntentText = "(Not Available)" // "com.easy_mode_replica.HomeButtonActivity"
    private var homeButtonLongPressIntentText = "(Not Available)" // "com.easy_mode_replica.HomeButtonLongPressActivity"
    private var holder: String? = null
    private var locationJSON: String? = null
    private var temperature: String? = null
    private var description: String? = null
    private var updatedAtFormatted: String? = null
    private var cityUserInput: String? = ""
    private var city: EditText? = null
    private var sunrise: Long = 0
    private var sunset: Long = 0
    private var updatedAt: Long = 0
    private lateinit var locationManager: LocationManager
    private val location: Location? = null
    private var latitude = 0.0
    private var longitude = 0.0
    private var runnableUserSet: Runnable? = null
    private var runnableGPSSet: Runnable? = null
    private var delay = 180000 // update delay (1000 per second, 900000 = 15mins);
    private var context: Context? = null


    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        apiWeatherCall()
        Toast.makeText(context, "Weather Update Pressed2", Toast.LENGTH_LONG).show()
    }

    private fun apiWeatherCall() {
        TODO("Not yet implemented")
    }
}
