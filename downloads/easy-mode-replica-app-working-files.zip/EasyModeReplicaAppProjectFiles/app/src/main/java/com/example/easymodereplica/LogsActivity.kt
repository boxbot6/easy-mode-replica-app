package com.example.easymodereplica

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.CallLog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat


class LogsActivity : AppCompatActivity() {
    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startActivity()
        finish()
    }

    private fun startActivity() {
        //  checks if location permission is granted and makes a dialog box to switch it on
        if (ContextCompat.checkSelfPermission(
                this@LogsActivity,
                Manifest.permission.READ_CALL_LOG
            ) == PackageManager.PERMISSION_GRANTED
        ) {
//            Toast.makeText(this, "Location Is Allowed", Toast.LENGTH_SHORT).show();
            val showCallLog = Intent()
            showCallLog.setAction(Intent.ACTION_VIEW)
            showCallLog.setType(CallLog.Calls.CONTENT_TYPE)
            this.startActivity(showCallLog)
        } else {
            //  if not granted opens dialog box
            ActivityCompat.requestPermissions(
                this@LogsActivity,
                arrayOf(Manifest.permission.READ_CALL_LOG),
                1
            )
        }
    }
}