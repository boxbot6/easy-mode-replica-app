package com.example.easymodereplica

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews


open class Widget3Activity : AppWidgetProvider() {
    private var moreAppsButtonTouchActive = false
    private var moreAppsButtonIntentText: String? = null

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {

        val thisWidget = ComponentName(context, Widget3Activity::class.java)
        val allWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget)
        for (widgetId in allWidgetIds) {

            val remoteViews = RemoteViews(
                context.packageName,
                R.layout.activity_widget3
            )
            remoteViews.setOnClickPendingIntent(
                R.id.buttonMoreApps,
                getPendingSelfIntent(context)
            )
            appWidgetManager.updateAppWidget(widgetId, remoteViews)
        }
    }

    private fun getPendingSelfIntent(context: Context?): PendingIntent {
        val intent = Intent(context, javaClass)
        intent.setAction(onClickMoreApps)
        return PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_IMMUTABLE)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)


        //  load/save values
        val sharedSettings = context.getSharedPreferences("Shared_Settings", 0)
//        val editor = sharedSettings.edit()
        moreAppsButtonTouchActive = sharedSettings.getBoolean("moreAppsButtonTouchActive", moreAppsButtonTouchActive)
        moreAppsButtonIntentText = sharedSettings.getString("moreAppsButtonIntentText", moreAppsButtonIntentText)


        if (onClickMoreApps == intent.action && moreAppsButtonTouchActive) {
            try {
                val mac = moreAppsButtonIntentText?.let { Class.forName(it) }
                val logsIntent = Intent(context, mac)
                context.startActivity(logsIntent)
            } catch (ignored: ClassNotFoundException) {
            }
        }
    }

    companion object {
        private const val onClickMoreApps = "onClickMoreAppsTag"
    }
}