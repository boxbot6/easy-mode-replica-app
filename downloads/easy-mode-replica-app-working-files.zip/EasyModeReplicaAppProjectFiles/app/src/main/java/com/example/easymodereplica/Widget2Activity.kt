package com.example.easymodereplica

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews


class Widget2Activity : AppWidgetProvider() {
    private var logsButtonTouchActive = false
    private var logsButtonIntentText: String? = null


    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val thisWidget = ComponentName(
            context,
            Widget2Activity::class.java
        )
        val allWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget)
        for (widgetId in allWidgetIds) {
            val remoteViews = RemoteViews(
                context.packageName,
                R.layout.activity_widget2
            )
            remoteViews.setOnClickPendingIntent(
                R.id.buttonLogs,
                getPendingSelfIntent(context)
            )
            appWidgetManager.updateAppWidget(widgetId, remoteViews)
        }
    }

    private fun getPendingSelfIntent(context: Context?): PendingIntent {
        val intent = Intent(context, javaClass)
        intent.setAction(onClickLogs)
        return PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_IMMUTABLE)
    }


    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)

        //  load/save values
        val sharedSettings = context.getSharedPreferences("Shared_Settings", 0)
        //  val editor = Shared_Settings.edit()
        logsButtonTouchActive = sharedSettings.getBoolean("logsButtonTouchActive", logsButtonTouchActive)
        logsButtonIntentText = sharedSettings.getString("logsButtonIntentText", logsButtonIntentText)

        if (onClickLogs == intent.action && logsButtonTouchActive) {
            try {
                val lbc = logsButtonIntentText?.let { Class.forName(it) }
                val logsIntent = Intent(context, lbc)
                context.startActivity(logsIntent)
            } catch (ignored: ClassNotFoundException) {
            }
        }
    }

    companion object {
        private const val onClickLogs = "OnClickLogsTag"
    }
}